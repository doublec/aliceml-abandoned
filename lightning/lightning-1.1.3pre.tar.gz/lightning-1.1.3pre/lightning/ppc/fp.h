/******************************** -*- C -*- ****************************
 *
 *	Run-time assembler & support macros for the Sparc math unit
 *
 ***********************************************************************/


/***********************************************************************
 *
 * Copyright 2000, 2001, 2002 Free Software Foundation, Inc.
 * Written by Paolo Bonzini.
 *
 * This file is part of GNU lightning.
 *
 * GNU lightning is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation; either version 2.1, or (at your option)
 * any later version.
 * 
 * GNU lightning is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with GNU lightning; see the file COPYING.LESSER; if not, write to the
 * Free Software Foundation, 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 *
 ***********************************************************************/




#ifndef __lightning_asm_fp_h
#define __lightning_asm_fp_h


#define _A(   OP,RD,RA,RB,RC,XO,RCx)  	_jit_I((_u6(OP)<<26)|(_u5(RD)<<21)|(_u5(RA)<<16)|( _u5(RB)<<11)|_u5(RC)<<6|    (_u5(XO)<<1)|_u1(RCx))


#define LFDrri(RD,RA,imm)       _D(50,RD,RA,imm)
#define LFDUrri(RD,RA,imm)      _D(51,RD,RA,imm)
#define LFDUxrrr(RD,RA,RB)      _X(31,RD,RA,RB,631,0)
#define LFDxrrr(RD,RA,RB)       _X(31,RD,RA,RB,599,0)

#define LFSrri(RD,RA,imm)       _D(48,RD,RA,imm)
#define LFSUrri(RD,RA,imm)      _D(49,RD,RA,imm)
#define LFSUxrrr(RD,RA,RB)      _X(31,RD,RA,RB,567,0)
#define LFSxrrr(RD,RA,RB)       _X(31,RD,RA,RB,535,0)

#define STFDrri(RS,RA,imm)      _D(54,RS,RA,imm)
#define STFDUrri(RS,RA,imm)     _D(55,RS,RA,imm)
#define STFDUxrrr(RS,RA,RB)     _X(31,RS,RA,RB,759,0)
#define STFDxrrr(RS,RA,RB)      _X(31,RS,RA,RB,727,0)

#define STFSrri(RS,RA,imm)      _D(52,RS,RA,imm)
#define STFSUrri(RS,RA,imm)     _D(53,RS,RA,imm)
#define STFSUxrrr(RS,RA,RB)     _X(31,RS,RA,RB,695,0)
#define STFSxrrr(RS,RA,RB)      _X(31,RS,RA,RB,663,0)

#define FADDDrrr(RD,RA,RB)       _A(63,RD,RA,RB,0,21,0)
#define FADDSrrr(RD,RA,RB)       _A(59,RD,RA,RB,0,21,0)
#define FSUBDrrr(RD,RA,RB)       _A(63,RD,RA,RB,0,20,0)
#define FSUBSrrr(RD,RA,RB)       _A(59,RD,RA,RB,0,20,0)
#define FMULDrrr(RD,RA,RC)       _A(63,RD,RA,0,RC,25,0)
#define FMULSrrr(RD,RA,RC)       _A(59,RD,RA,0,RC,25,0)
#define FDIVDrrr(RD,RA,RB)       _A(63,RD,RA,RB,0,18,0)
#define FDIVSrrr(RD,RA,RB)       _A(59,RD,RA,RB,0,25,0)
#define FSQRTDrr(RD,RB)          _A(63,RD,0,RB,0,22,0)
#define FSQRTSrr(RD,RB)          _A(59,RD,0,RB,0,22,0)
#define FSELrrrr(RD,RA,RB,RC)    _A(63,RD,RA,RB,RC,23,0)
#define FCTIWrr(RD,RB)           _X(63,RD,0,RB,14,0)
#define FCTIWZrr(RD,RB)          _X(63,RD,0,RB,15,0)
#define FRSPrr(RD,RB)            _X(63,RD,0,RB,12,0)
#define FABSrr(RD,RB)            _X(63,RD,0,RB,264,0)
#define FNABSrr(RD,RB)           _X(63,RD,0,RB,136,0)
#define FNEGrr(RD,RB)            _X(63,RD,0,RB,40,0)
#define FMOVErr(RD,RB)           _X(63,RD,0,RB,72,0)
#define FCMPOrrr(CR,RA,RB)       _X(63,_u3((CR)<<2),RA,RB,32,0)
#define FCMPUrrr(CR,RA,RB)       _X(63,_u3((CR)<<2),RA,RB,0,0)

#define JIT_FPR0 14
#define JIT_FPR1 15 
#define JIT_FPR2 16 
#define JIT_FPR3 17 
#define JIT_FPR4 18
#define JIT_FPR5 19
#define JIT_FPX0 20
#define JIT_FPX1 21
#define JIT_FPX2 22
#define JIT_FPX3 23
#define JIT_FPX4 24

#define JIT_FPFR 13

/* dummy for now */

/* Make space for 1 or 2 words, store address in REG */
#define jit_data(REG, D1)	        (_FBA	(18, 8, 0, 1),  _jit_L(D1), MFLRr(REG))
#define jit_data2(REG, D1, D2)	        (_FBA	(18, 12, 0, 1), _jit_L(D1), _jit_L(D2), MFLRr(REG))

#define jit_fpimm(reg0, first, second)	\
   (jit_data2(JIT_AUX, (first), (second)),	\
    jit_ldxi_d((reg0), JIT_AUX, 0))

#define jit_fpdimm(reg0,d) do {                 \
      double v = (d);                            \
      unsigned int* adr = (unsigned int*)&v;     \
      jit_fpimm((reg0),adr[0],adr[1]);           \
   } while(0) 


#define jit_addr_d(rd,s1,s2)  FADDDrrr((rd),(s1),(s2))
#define jit_subr_d(rd,s1,s2)  FSUBDrrr((rd),(s1),(s2))
#define jit_mulr_d(rd,s1,s2)  FMULDrrr((rd),(s1),(s2))
#define jit_divr_d(rd,s1,s2)  FDIVDrrr((rd),(s1),(s2))

#define jit_addr_f(rd,s1,s2)  FADDSrrr((rd),(s1),(s2))
#define jit_subr_f(rd,s1,s2)  FSUBSrrr((rd),(s1),(s2))
#define jit_mulr_f(rd,s1,s2)  FMULSrrr((rd),(s1),(s2))
#define jit_divr_f(rd,s1,s2)  FDIVSrrr((rd),(s1),(s2))

#define jit_movr_d(rd,rs)     ( (rd) == (rs) ? 0 : FMOVErr((rd),(rs)))
#define jit_movi_d(rd,imm)    jit_fpdimm((rd),(imm))

#define jit_movr_f(rd,rs)     ( (rd) == (rs) ? 0 : FMOVErr((rd),(rs)))
#define jit_movi_f(rd,imm)    (jit_data(JIT_AUX,(imm)),jit_ldxi_f((rd),JIT_AUX,0))

#define jit_abs_d(rd,rs)       FABSrr((rd),(rs))
#define jit_neg_d(rd,rs)       FNEGrr((rd),(rs))
#define jit_sqrt_d(rd,rs)      FSQRTDrr((rd),(rs))


#define jit_ldxi_f(reg0, rs, is)    (_siP(16,(is)) ? LFSrri((reg0),(rs),(is)) : (MOVEIri(JIT_AUX,(is)),LFSxrrr((reg0),(rs),JIT_AUX))) 
#define jit_ldxi_d(reg0, rs, is)    (_siP(16,(is)) ? LFDrri((reg0),(rs),(is)) : (MOVEIri(JIT_AUX,(is)),LFDxrrr((reg0),(rs),JIT_AUX)))
#define jit_ldxr_f(reg0, s1, s2)    LFSxrrr((reg0),(s1),(s2))
#define jit_ldxr_d(reg0, s1, s2)    LFDxrrr((reg0),(s1),(s2))
#define jit_ldi_f(reg0, is)          (_siP(16,(is)) ? LFSrri((reg0),0,(is)) : (MOVEIri(JIT_AUX,(is)),LFSrri((reg0),JIT_AUX,0)))
#define jit_ldi_d(reg0, is)          (_siP(16,(is)) ? LFDrri((reg0),0,(is)) : (MOVEIri(JIT_AUX,(is)),LFDrri((reg0),JIT_AUX,0)))
#define jit_ldr_f(reg0, rs)          LFSrri((reg0),(rs),0)
#define jit_ldr_d(reg0, rs)          LFDrri((reg0),(rs),0)
#define jit_stxi_f(id, rd, reg0)     (_siP(16,(id)) ? STFSrri((reg0),(rd),(id)) : (MOVEIri(JIT_AUX,(id)),STFSrri((reg0),(rd),JIT_AUX))) 
#define jit_stxi_d(id, rd, reg0)     (_siP(16,(id)) ? STFDrri((reg0),(rd),(id)) : (MOVEIri(JIT_AUX,(id)),STFDrri((reg0),(rd),JIT_AUX))) 
#define jit_stxr_f(d1, d2, reg0)     STFSxrrr((reg0),(d1),(d2))
#define jit_stxr_d(d1, d2, reg0)     STFDxrrr((reg0),(d1),(d2))
#define jit_sti_f(id, reg0)          (_siP(16,(id)) ? STFSrri((reg0),0,(id)) : (MOVEIri(JIT_AUX,(id)),STFSrri((reg0),JIT_AUX,0)))
#define jit_sti_d(id, reg0)          (_siP(16,(id)) ? STFDrri((reg0),0,(id)) : (MOVEIri(JIT_AUX,(id)),STFDrri((reg0),JIT_AUX,0)))
#define jit_str_f(rd, reg0)          STFSrri((reg0),(rd),0)
#define jit_str_d(rd, reg0)          STFDrri((reg0),(rd),0)

#define jit_fpboolr(d, s1, s2, rcbit) (FCMPOrrr(_cr0,(s1),(s2)),MFCRr((d)), EXTRWIrrii((d), (d), 1, (rcbit)))
#define jit_fpboolr2(d, s1, s2,rcbit) (FCMPOrrr(_cr0,(s1),(s2)),MFCRr((d)), EXTRWIrrii((d), (d), 1, (rcbit)), XORIrri((d), (d), 1))
#define jit_fpboolur(d, s1, s2, rcbit) (FCMPUrrr(_cr0,(s1),(s2)),MFCRr((d)), EXTRWIrrii((d), (d), 1, (rcbit)))
#define jit_fpboolur2(d, s1, s2,rcbit) (FCMPUrrr(_cr0,(s1),(s2)),MFCRr((d)), EXTRWIrrii((d), (d), 1, (rcbit)), XORIrri((d), (d), 1))

#define jit_gtr_d(d, s1, s2)      jit_fpboolr ((d),(s1),(s2),_gt)   
#define jit_ger_d(d, s1, s2)      jit_fpboolr2((d),(s1),(s2),_lt)   
#define jit_ltr_d(d, s1, s2)      jit_fpboolr ((d),(s1),(s2),_lt)         
#define jit_ler_d(d, s1, s2)      jit_fpboolr2((d),(s1),(s2),_gt)         
#define jit_eqr_d(d, s1, s2)      jit_fpboolr ((d),(s1),(s2),_eq)         
#define jit_ner_d(d, s1, s2)      jit_fpboolr2((d),(s1),(s2),_eq)               
#define jit_unler_d(d, s1, s2)    0      
#define jit_unltr_d(d, s1, s2)    0      
#define jit_unger_d(d, s1, s2)    0      
#define jit_ungtr_d(d, s1, s2)    0      
#define jit_ltgtr_d(d, s1, s2)    (jit_fpboolur((d),(s1),(2),_un))
#define jit_uneqr_d(d, s1, s2)    0      
#define jit_ordr_d(d, s1, s2)     0      
#define jit_unordr_d(d, s1, s2)   0      

#define jit_bgtr_d(d, s1, s2)           0
#define jit_bger_d(d, s1, s2)           0
#define jit_bunler_d(d, s1, s2)         0
#define jit_bunltr_d(d, s1, s2)         0
#define jit_bltr_d(d, s1, s2)           0
#define jit_bler_d(d, s1, s2)           0
#define jit_bunger_d(d, s1, s2)         0
#define jit_bungtr_d(d, s1, s2)         0
#define jit_beqr_d(d, s1, s2)           0
#define jit_bner_d(d, s1, s2)           0
#define jit_bltgtr_d(d, s1, s2)         0
#define jit_buneqr_d(d, s1, s2)         0
#define jit_bordr_d(d, s1, s2)          0
#define jit_bunordr_d(d, s1, s2)        0

#define jit_getarg_f(rd, ofs)        jit_movr_f((rd),(ofs))
#define jit_getarg_d(rd, ofs)        jit_movr_d((rd),(ofs))
#define jit_pusharg_d(rs)	     (_jitl.nextarg_putd--,jit_movr_d((_jitl.nextarg_putf+_jitl.nextarg_putd+1), (rs)))
#define jit_pusharg_f(rs)	     (_jitl.nextarg_putf--,jit_movr_f((_jitl.nextarg_putf+_jitl.nextarg_putd+1), (rs)))
#define jit_retval_d(op1)            jit_movr_d(1, (op1))
#define jit_retval_f(op1)            jit_movr_f(1, (op1))


#define jit_floorr_d_i(rd,rs) 0
#define jit_ceilr_d_i(rd,rs) 0
#define jit_roundr_d_i(rd,rs) 0
#define jit_truncr_d_i(rd,rs) 0  

#if 0
/* The rest of the old code */

#define jit_floor(rd, reg0)	0

#define jit_ceil(rd, reg0)	0

#define jit_call_fp(rd, reg0, fn)						\
	jit_fail(#fn " not supported", __FILE__, __LINE__, __FUNCTION__)
/*	pass reg0 as first parameter of rd
	bl	fn
	mr	r3, rd */

#define jit_trunc(rd, reg0)	(jit_data((rd), 0),                     \
                                 FCTIWZrr(JIT_FPFR- (reg0), JIT_FPFR- (reg0)), \
                                 STFIWXrrr(JIT_FPFR- (reg0), 0, (rd)),  \
                                 LWZrm((rd), 0, (rd)))
          
#define jit_round(rd, reg0)	(jit_data((rd), 0),                     \
				FCTIWrr(JIT_FPFR- (reg0), JIT_FPFR- (reg0)),		\
				STFIWXrrr(JIT_FPFR- (reg0), 0, (rd)),			\
				LWZrm((rd), 0, (rd)))
				
#define jit_cmp(le, ge, reg0)	(FCMPOirr(7, JIT_FPFR - (reg0), 0),	   	   \
				CRORiii(28 + _gt, 28 + _gt, 28 + _eq),	   \
				CRORiii(28 + _lt, 28 + _lt, 28 + _eq),	   \
				MFCRr((ge)), 				   \
				EXTRWIrrii((le), (ge), 1, 28 + _lt),	   \
				EXTRWIrrii((ge), (ge), 1, 28 + _gt))

#endif

#endif /* __lightning_asm_h */
